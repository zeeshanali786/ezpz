import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';  
import { ProviderService } from '../provider.service';  

import { Serviceprovider } from '../provider';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  allProviders!: Observable<Serviceprovider[]>;  
  

  constructor(private providerService:ProviderService) { }  

  ngOnInit() {  
    this.loadAllProviders();  
  }  

  loadAllProviders() {  
     
    this.allProviders = this.providerService.getAllProvider();  
  } 

  share() {
    window.alert('The product has been shared!');
  }
}