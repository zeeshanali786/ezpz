export class Serviceprovider {  
  serviceProviderID: string | undefined;  
  Name!: string;  
  Address!: string; 
  BusinessCategory!: string; 
  ContactEmail!: string; 
  ContactPhone!: string; 
  Credentials!: string; 
  DailyWorkingSchedule!: string; 
}  




