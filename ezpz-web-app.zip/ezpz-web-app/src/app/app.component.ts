import { Component, OnInit } from '@angular/core';
import { slideInAnimation } from './animations';
import { HttpClient } from '@angular/common/http'; 
import {
  Event,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router
} from '@angular/router';
import { Observable } from 'rxjs';  
import { CategoryService } from './category.service';  

import { Category } from './category';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ],
  animations: [ slideInAnimation ]
})
export class AppComponent implements OnInit  {
  allCategories!: Observable<Category[]>;  
  data: any;

  keyword = 'name';
  states = [
    {
      name: 'Arkansas',
      population: '2.978M',
      flag: 'https://upload.wikimedia.org/wikipedia/commons/9/9d/Flag_of_Arkansas.svg'
    },
    {
      name: 'California',
      population: '39.14M',
      flag: 'https://upload.wikimedia.org/wikipedia/commons/0/01/Flag_of_California.svg'
    },
    {
      name: 'Florida',
      population: '20.27M',
      flag: 'https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Florida.svg'
    },
    {
      name: 'Texas',
      population: '27.47M',
      flag: 'https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Texas.svg'
    }
  ];
  

  loading = false;

  constructor(private router: Router, private categoryService:CategoryService, private http: HttpClient) {
    this.router.events.subscribe((event: Event) => {
      switch (true) {
        case event instanceof NavigationStart: {
          this.loading = true;
          break;
        }

        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loading = false;
          break;
        }
        default: {
          break;
        }
      }
    });
  }

  ngOnInit() {  
    this.loadAllCategories();  
  }  

    
  getServerResponse() {
 
    this.http.get<any>("https://hxb71r9qs8.execute-api.us-east-2.amazonaws.com/test").subscribe(data => {
      this.data = data.name;
  })

      
  }

  loadAllCategories() {  
     
    this.allCategories = this.categoryService.getAllCategories();  
  } 

}