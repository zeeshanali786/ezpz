import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';  
import { BrowserAnimationsModule } from  '@angular/platform-browser/animations';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';

import { AppComponent } from './app.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { ProductListComponent } from './product-list/product-list.component';
import { PopularServiceComponent } from './popular-service/popular-service.component';


@NgModule({
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,  
    AutocompleteLibModule,
    RouterModule.forRoot([
      { path: 'providers', component: ProductListComponent, data: {animation: 'Providers'} },
      { path: 'popularservice', component: PopularServiceComponent, data: {animation: 'Popularservice'} },
      {path: '', redirectTo: '/popularservice', pathMatch: 'full'},
    ])
  ],
  declarations: [
    AppComponent,
    TopBarComponent,
    ProductListComponent,
    PopularServiceComponent
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/